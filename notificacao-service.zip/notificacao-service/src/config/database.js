const sqlite3 = require("sqlite3").verbose();
const path = require("path");

const DB_PATH = process.env.DB_PATH || "./notificacoes.db";

const db = new sqlite3.Database(path.resolve(DB_PATH), (err) => {
  if (err) {
    console.error("[DB] Erro ao conectar no banco de dados:", err.message);
    process.exit(1);
  }
  console.log("[DB] Conectado ao banco SQLite em:", path.resolve(DB_PATH));
});

// Cria a tabela de log de notificações caso não exista
db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS notificacoes (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      tipo        TEXT    NOT NULL,
      destinatario TEXT   NOT NULL,
      status      TEXT    NOT NULL DEFAULT 'enviado',  -- 'enviado' | 'falhou'
      erro        TEXT,
      dados       TEXT,   -- JSON com os dados usados no template
      criado_em   DATETIME DEFAULT (datetime('now', 'localtime'))
    )
  `, (err) => {
    if (err) console.error("[DB] Erro ao criar tabela:", err.message);
    else console.log("[DB] Tabela 'notificacoes' pronta.");
  });
});

module.exports = db;
