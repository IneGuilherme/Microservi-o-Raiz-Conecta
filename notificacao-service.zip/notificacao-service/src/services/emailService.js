const nodemailer = require("nodemailer");
const db = require("../config/database");
const { templates, camposObrigatorios } = require("../templates/emails");

// Configura o transportador (criado uma vez, reutilizado)
const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});

/**
 * Valida se todos os campos obrigatórios do tipo estão presentes em `dados`.
 */
function validarDados(tipo, dados) {
  const obrigatorios = camposObrigatorios[tipo];
  if (!obrigatorios) return `Tipo de notificação desconhecido: '${tipo}'`;

  const faltando = obrigatorios.filter((campo) => !dados[campo]);
  if (faltando.length > 0) {
    return `Campos obrigatórios ausentes para o tipo '${tipo}': ${faltando.join(", ")}`;
  }
  return null; // sem erro
}

/**
 * Salva o resultado do envio no banco de dados (log).
 */
function salvarLog({ tipo, destinatario, status, erro, dados }) {
  const sql = `
    INSERT INTO notificacoes (tipo, destinatario, status, erro, dados)
    VALUES (?, ?, ?, ?, ?)
  `;
  db.run(sql, [tipo, destinatario, status, erro || null, JSON.stringify(dados)], (err) => {
    if (err) console.error("[Log] Erro ao salvar log:", err.message);
  });
}

/**
 * Envia um e-mail de notificação e registra o resultado no banco.
 * Retorna { sucesso: boolean, mensagem: string }
 */
async function enviarNotificacao({ tipo, destinatario, dados }) {
  // 1. Valida os dados de entrada
  const erroValidacao = validarDados(tipo, dados);
  if (erroValidacao) {
    return { sucesso: false, mensagem: erroValidacao, status: 400 };
  }

  // 2. Monta o e-mail com o template correto
  const template = templates[tipo](dados);

  try {
    // 3. Envia o e-mail
    await transporter.sendMail({
      from: process.env.EMAIL_FROM,
      to: destinatario,
      subject: template.assunto,
      html: template.html,
    });

    // 4. Salva log de sucesso
    salvarLog({ tipo, destinatario, status: "enviado", dados });
    console.log(`[Email] ✅ Enviado | tipo: ${tipo} | para: ${destinatario}`);

    return { sucesso: true, mensagem: "E-mail enviado com sucesso!", status: 200 };

  } catch (err) {
    // 5. Salva log de falha
    salvarLog({ tipo, destinatario, status: "falhou", erro: err.message, dados });
    console.error(`[Email] ❌ Falha | tipo: ${tipo} | para: ${destinatario} | erro: ${err.message}`);

    return { sucesso: false, mensagem: "Falha ao enviar e-mail.", status: 500 };
  }
}

/**
 * Busca o histórico de notificações do banco (para a rota GET /notificacoes/historico).
 */
function buscarHistorico({ limite = 50, tipo, status } = {}) {
  return new Promise((resolve, reject) => {
    let sql = "SELECT * FROM notificacoes";
    const params = [];
    const filtros = [];

    if (tipo)   { filtros.push("tipo = ?");   params.push(tipo); }
    if (status) { filtros.push("status = ?"); params.push(status); }
    if (filtros.length) sql += " WHERE " + filtros.join(" AND ");

    sql += " ORDER BY criado_em DESC LIMIT ?";
    params.push(Number(limite));

    db.all(sql, params, (err, rows) => {
      if (err) reject(err);
      else resolve(rows);
    });
  });
}

module.exports = { enviarNotificacao, buscarHistorico };
