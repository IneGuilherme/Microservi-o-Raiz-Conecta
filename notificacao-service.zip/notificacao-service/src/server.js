require("dotenv").config();

const express = require("express");
const cors    = require("cors");
const rateLimit = require("express-rate-limit");

// Inicializa o banco de dados (cria a tabela se não existir)
require("./config/database");

const notificacoesRouter = require("./routes/notificacoes");

const app  = express();
const PORT = process.env.PORT || 3001;

// -----------------------------------------------
// Middlewares globais
// -----------------------------------------------

// Permite chamadas do frontend Next.js (ajuste a origem conforme necessário)
app.use(cors({
  origin: ["http://localhost:3000", "http://localhost:3001"],
  methods: ["GET", "POST"],
}));

app.use(express.json());

// Rate limiting: máximo 30 requisições por minuto por IP
const limiter = rateLimit({
  windowMs: 60 * 1000,
  max: 30,
  message: { erro: "Muitas requisições. Aguarde um momento." },
});
app.use(limiter);

// -----------------------------------------------
// Rotas
// -----------------------------------------------
app.use("/notificacoes", notificacoesRouter);

// Health check — útil para monitoramento e deploy
app.get("/health", (req, res) => {
  res.status(200).json({
    servico:  "raiz-conecta-notificacao-service",
    status:   "online",
    versao:   "1.0.0",
    horario:  new Date().toISOString(),
  });
});

// Rota não encontrada
app.use((req, res) => {
  res.status(404).json({ erro: `Rota '${req.path}' não encontrada neste serviço.` });
});

// -----------------------------------------------
// Inicia o servidor
// -----------------------------------------------
app.listen(PORT, () => {
  console.log("================================================");
  console.log("  🌱 Raiz Conecta — Microsserviço de E-mail");
  console.log(`  Rodando em: http://localhost:${PORT}`);
  console.log("================================================");
  console.log(`  POST  /notificacoes/enviar    → envia e-mail`);
  console.log(`  GET   /notificacoes/historico → log de envios`);
  console.log(`  GET   /notificacoes/tipos     → tipos disponíveis`);
  console.log(`  GET   /health                 → status do serviço`);
  console.log("================================================");
});
