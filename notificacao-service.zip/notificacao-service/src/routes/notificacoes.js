const express = require("express");
const router = express.Router();
const { enviarNotificacao, buscarHistorico } = require("../services/emailService");
const { templates } = require("../templates/emails");

// -----------------------------------------------
// Middleware: valida a API_SECRET_KEY no header
// -----------------------------------------------
function autenticar(req, res, next) {
  const chave = req.headers["x-api-key"];
  if (!chave || chave !== process.env.API_SECRET_KEY) {
    return res.status(401).json({ erro: "Não autorizado. Informe x-api-key válida." });
  }
  next();
}

// -----------------------------------------------
// POST /notificacoes/enviar
// Envia um e-mail de notificação
// -----------------------------------------------
// Body esperado:
// {
//   "tipo": "cadastro_aprovado",
//   "destinatario": "email@exemplo.com",
//   "dados": { "nome": "João Silva", "tipo_perfil": "Produtor" }
// }
router.post("/enviar", autenticar, async (req, res) => {
  const { tipo, destinatario, dados } = req.body;

  // Validação da estrutura básica
  if (!tipo || !destinatario || !dados) {
    return res.status(400).json({
      erro: "Campos obrigatórios ausentes.",
      obrigatorios: ["tipo", "destinatario", "dados"],
    });
  }

  const resultado = await enviarNotificacao({ tipo, destinatario, dados });
  return res.status(resultado.status).json({ mensagem: resultado.mensagem });
});

// -----------------------------------------------
// GET /notificacoes/historico
// Retorna o log de notificações enviadas
// Query params opcionais: ?limite=20&tipo=novo_pedido&status=falhou
// -----------------------------------------------
router.get("/historico", autenticar, async (req, res) => {
  try {
    const { limite, tipo, status } = req.query;
    const registros = await buscarHistorico({ limite, tipo, status });
    return res.status(200).json({ total: registros.length, registros });
  } catch (err) {
    console.error("[Rota] Erro ao buscar histórico:", err.message);
    return res.status(500).json({ erro: "Erro ao buscar histórico." });
  }
});

// -----------------------------------------------
// GET /notificacoes/tipos
// Lista todos os tipos de notificação disponíveis
// (não requer autenticação — apenas informativo)
// -----------------------------------------------
router.get("/tipos", (req, res) => {
  return res.status(200).json({
    tipos_disponiveis: Object.keys(templates),
  });
});

module.exports = router;
