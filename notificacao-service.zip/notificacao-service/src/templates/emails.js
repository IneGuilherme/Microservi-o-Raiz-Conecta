/**
 * Templates de e-mail para cada tipo de notificação do Raiz Conecta.
 * Cada template recebe um objeto `dados` com as variáveis necessárias.
 */

const BASE_STYLE = `
  font-family: 'Segoe UI', Arial, sans-serif;
  max-width: 600px;
  margin: 0 auto;
  background: #f9f5f0;
  border-radius: 12px;
  overflow: hidden;
`;

const HEADER = (titulo) => `
  <div style="background: #2d6a2d; padding: 28px 32px; text-align: center;">
    <h1 style="color: #ffffff; margin: 0; font-size: 22px; font-weight: 700;">🌱 Raiz Conecta</h1>
    <p style="color: #a8d5a8; margin: 6px 0 0; font-size: 14px;">${titulo}</p>
  </div>
`;

const FOOTER = `
  <div style="background: #e8f0e8; padding: 16px 32px; text-align: center; border-top: 1px solid #c5d9c5;">
    <p style="color: #6b8f6b; font-size: 12px; margin: 0;">
      Raiz Conecta — Conectando produtores e mercados<br/>
      Este é um e-mail automático, não responda.
    </p>
  </div>
`;

const BODY = (conteudo) => `
  <div style="padding: 32px; background: #ffffff;">
    ${conteudo}
  </div>
`;

// ============================================================
const templates = {

  cadastro_aprovado: (dados) => ({
    assunto: "✅ Seu cadastro foi aprovado — Raiz Conecta",
    html: `
      <div style="${BASE_STYLE}">
        ${HEADER("Validação de Cadastro")}
        ${BODY(`
          <h2 style="color: #2d6a2d; margin-top: 0;">Olá, ${dados.nome}! 👋</h2>
          <p style="color: #444; line-height: 1.6;">
            Temos uma ótima notícia: seu cadastro como <strong>${dados.tipo_perfil || "usuário"}</strong>
            na plataforma <strong>Raiz Conecta</strong> foi <strong>aprovado</strong>!
          </p>
          <p style="color: #444; line-height: 1.6;">
            Você já pode acessar sua conta e começar a usar todos os recursos da plataforma.
          </p>
          <div style="text-align: center; margin: 28px 0;">
            <a href="#" style="background: #2d6a2d; color: #fff; padding: 12px 28px;
              border-radius: 8px; text-decoration: none; font-weight: 600; font-size: 15px;">
              Acessar Minha Conta
            </a>
          </div>
        `)}
        ${FOOTER}
      </div>
    `,
  }),

  cadastro_recusado: (dados) => ({
    assunto: "❌ Cadastro não aprovado — Raiz Conecta",
    html: `
      <div style="${BASE_STYLE}">
        ${HEADER("Validação de Cadastro")}
        ${BODY(`
          <h2 style="color: #b94444; margin-top: 0;">Olá, ${dados.nome}.</h2>
          <p style="color: #444; line-height: 1.6;">
            Infelizmente seu cadastro na <strong>Raiz Conecta</strong> não foi aprovado neste momento.
          </p>
          ${dados.motivo ? `<p style="color: #444; line-height: 1.6;"><strong>Motivo:</strong> ${dados.motivo}</p>` : ""}
          <p style="color: #444; line-height: 1.6;">
            Se tiver dúvidas, entre em contato com nossa equipe.
          </p>
        `)}
        ${FOOTER}
      </div>
    `,
  }),

  novo_pedido: (dados) => ({
    assunto: "🛒 Novo pedido recebido — Raiz Conecta",
    html: `
      <div style="${BASE_STYLE}">
        ${HEADER("Novo Pedido")}
        ${BODY(`
          <h2 style="color: #2d6a2d; margin-top: 0;">Novo pedido, ${dados.nome}!</h2>
          <p style="color: #444; line-height: 1.6;">
            O mercado <strong>${dados.mercado}</strong> fez um pedido para você.
          </p>
          ${dados.itens ? `
            <div style="background: #f0f7f0; border-radius: 8px; padding: 16px; margin: 16px 0;">
              <strong style="color: #2d6a2d;">Itens solicitados:</strong>
              <p style="margin: 8px 0 0; color: #555;">${dados.itens}</p>
            </div>
          ` : ""}
          <p style="color: #444;">Acesse seu painel para confirmar ou negar a disponibilidade dos produtos.</p>
          <div style="text-align: center; margin: 28px 0;">
            <a href="#" style="background: #2d6a2d; color: #fff; padding: 12px 28px;
              border-radius: 8px; text-decoration: none; font-weight: 600; font-size: 15px;">
              Ver Pedido
            </a>
          </div>
        `)}
        ${FOOTER}
      </div>
    `,
  }),

  pedido_confirmado: (dados) => ({
    assunto: "📦 Pedido confirmado — Raiz Conecta",
    html: `
      <div style="${BASE_STYLE}">
        ${HEADER("Confirmação de Pedido")}
        ${BODY(`
          <h2 style="color: #2d6a2d; margin-top: 0;">Pedido confirmado! 🎉</h2>
          <p style="color: #444; line-height: 1.6;">
            Olá, <strong>${dados.nome}</strong>! O produtor <strong>${dados.produtor || "parceiro"}</strong>
            confirmou seu pedido.
          </p>
          <p style="color: #444; line-height: 1.6;">Em breve os produtos estarão em rota de entrega.</p>
        `)}
        ${FOOTER}
      </div>
    `,
  }),

  problema_entrega: (dados) => ({
    assunto: "⚠️ Problema reportado em entrega — Raiz Conecta",
    html: `
      <div style="${BASE_STYLE}">
        ${HEADER("Alerta de Entrega")}
        ${BODY(`
          <h2 style="color: #b94444; margin-top: 0;">Atenção, Administrador</h2>
          <p style="color: #444; line-height: 1.6;">
            O entregador <strong>${dados.entregador}</strong> reportou um problema durante a entrega.
          </p>
          <div style="background: #fff3cd; border-left: 4px solid #f59e0b; border-radius: 4px; padding: 16px; margin: 16px 0;">
            <strong>Descrição do problema:</strong>
            <p style="margin: 8px 0 0; color: #555;">${dados.descricao}</p>
          </div>
          <p style="color: #444;">Acesse o painel administrativo para tomar as devidas providências.</p>
        `)}
        ${FOOTER}
      </div>
    `,
  }),

};

// Campos obrigatórios por tipo
const camposObrigatorios = {
  cadastro_aprovado:  ["nome"],
  cadastro_recusado:  ["nome"],
  novo_pedido:        ["nome", "mercado"],
  pedido_confirmado:  ["nome"],
  problema_entrega:   ["entregador", "descricao"],
};

module.exports = { templates, camposObrigatorios };
