# 🌱 Raiz Conecta — Microsserviço de Notificações por E-mail

Microsserviço independente responsável por enviar e registrar notificações
por e-mail para os usuários da plataforma Raiz Conecta.

---

## 📁 Estrutura do Projeto

```
notificacao-service/
├── src/
│   ├── server.js               ← Ponto de entrada, configuração Express
│   ├── config/
│   │   └── database.js         ← Conexão e criação do banco SQLite
│   ├── routes/
│   │   └── notificacoes.js     ← Definição dos endpoints da API
│   ├── services/
│   │   └── emailService.js     ← Lógica de negócio (envio + log)
│   └── templates/
│       └── emails.js           ← Templates HTML dos e-mails
├── .env.example                ← Modelo de variáveis de ambiente
├── package.json
└── README.md
```

---

## ⚙️ Como Rodar

### 1. Instalar dependências
```bash
npm install
```

### 2. Configurar variáveis de ambiente
```bash
cp .env.example .env
# Edite o .env com seus dados reais
```

> **Atenção:** No Gmail, use uma **Senha de App** (não a senha normal).
> Ative em: Conta Google → Segurança → Verificação em 2 etapas → Senhas de App

### 3. Iniciar o servidor
```bash
# Produção
npm start

# Desenvolvimento (reinicia automaticamente ao salvar)
npm run dev
```

O serviço estará disponível em: `http://localhost:3001`

---

## 🔐 Autenticação

Todas as rotas (exceto `/health` e `/notificacoes/tipos`) exigem o header:

```
x-api-key: SUA_API_SECRET_KEY
```

---

## 📡 Endpoints

### `GET /health`
Verifica se o serviço está online.

**Resposta:**
```json
{
  "servico": "raiz-conecta-notificacao-service",
  "status": "online",
  "versao": "1.0.0",
  "horario": "2025-06-01T12:00:00.000Z"
}
```

---

### `GET /notificacoes/tipos`
Lista todos os tipos de notificação disponíveis.

**Resposta:**
```json
{
  "tipos_disponiveis": [
    "cadastro_aprovado",
    "cadastro_recusado",
    "novo_pedido",
    "pedido_confirmado",
    "problema_entrega"
  ]
}
```

---

### `POST /notificacoes/enviar`
Envia um e-mail de notificação.

**Headers:**
```
Content-Type: application/json
x-api-key: SUA_API_SECRET_KEY
```

**Body:**
```json
{
  "tipo": "cadastro_aprovado",
  "destinatario": "joao@email.com",
  "dados": {
    "nome": "João Silva",
    "tipo_perfil": "Produtor"
  }
}
```

**Campos `dados` por tipo:**

| tipo | campos obrigatórios | campos opcionais |
|---|---|---|
| `cadastro_aprovado` | `nome` | `tipo_perfil` |
| `cadastro_recusado` | `nome` | `motivo` |
| `novo_pedido` | `nome`, `mercado` | `itens` |
| `pedido_confirmado` | `nome` | `produtor` |
| `problema_entrega` | `entregador`, `descricao` | — |

---

### `GET /notificacoes/historico`
Retorna o log de notificações enviadas.

**Query params opcionais:**
- `limite` (padrão: 50)
- `tipo` (ex: `novo_pedido`)
- `status` (`enviado` ou `falhou`)

**Exemplo:** `GET /notificacoes/historico?status=falhou&limite=10`

---

## 🔗 Como Chamar do Projeto Next.js

```typescript
// Em qualquer Server Action ou Route Handler do Next.js

await fetch("http://localhost:3001/notificacoes/enviar", {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
    "x-api-key": process.env.NOTIFICACAO_API_KEY,
  },
  body: JSON.stringify({
    tipo: "cadastro_aprovado",
    destinatario: usuario.email,
    dados: { nome: usuario.nome, tipo_perfil: "Produtor" },
  }),
});
```

Adicione no `.env.local` do projeto Next.js:
```
NOTIFICACAO_API_KEY=mesma_chave_do_microsservico
NOTIFICACAO_API_URL=http://localhost:3001
```
